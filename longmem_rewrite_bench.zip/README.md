# LongMemEval: question rewrite versus factual memory

공식 LongMemEval cleaned oracle 데이터에서 원본 질문과 대화 100개를 가져왔다.
이번 패키지에서는 새로운 synthetic 대화를 만들지 않는다. 원본 벤치마크 자체의 제작 방식을 자연 대화 수집이라고 단정하지 않는다.

| 유형 | 표본 |
|---|---:|
| multi-session | 34 |
| temporal-reasoning | 33 |
| knowledge-update | 33 |

seed=42, 유형별 무작위 선택. abstention 질문은 제외한다.
원본 session 시간순으로 정렬하고 role/content/timestamp를 그대로 보존했다.
`has_answer`는 모델 입력에서 제거하고 평가용 evidence_indices에만 보존한다.
원본 answer와 answer_session_ids도 모델 입력에 제공하지 않는다.
샘플 ID와 source SHA256은 samples_100.manifest.json에 기록한다.

## 이번 실험의 목적과 한계

앞선 CoQA/차량 catalog에는 이력과 별도로 답변 근거 문서가 있었다.
LongMemEval에서는 **대화 이력 자체가 답변 근거**다. 여러 세션의 사실, 시간 관계, 수정된 정보를 모아야 한다.
질문을 명확히 하는 rewriting과 사실을 보존하는 memory compression의 차이를 평가한다.

`rewrite_only`는 독립형 질문만 제공하며 별도 gold 문서/이력은 제공하지 않는다.
따라서 실패한다면 사실을 제거한 병목의 결과일 수 있다. 일반 RAG에서도 rewrite-only가 항상 나쁘다고 일반화할 수 없다.
충분히 긴 rewrite에 사실을 모두 넣으면 memory summary처럼 동작할 수 있으므로,
이번 실험에는 명시적으로 사실을 남기는 `rewrite_notes`를 추가했다.
질문 rewriting에는 답변/사실 요약을 붙이지 않도록 지시하며, notes는 근거 사실을 보존하도록 지시한다.

oracle 파일은 정답 근거 세션만 포함하며 noisy full-history 검색/선택 난이도를 측정하지 않는다.
세션 전체 안에는 무관한 턴이 있을 수 있다. gold turn만 제공하는 조건과는 다르다.
원본 질문 자체가 이미 독립형일 수 있어 이 실험은 순수한 대명사 해소 실험이 아니다.

## 실행

Python 3.10 이상, 외부 패키지 없음. 실제 100개 데이터 포함.

```bash
unzip longmem_rewrite_bench.zip
cd longmem_rewrite_bench
export OPENAI_API_KEY='YOUR_KEY'
python3 bench.py --n 100 --model gpt-6-luna --effort none \
  --judge --concurrency 4 --out results_longmem
```

처음에는 `--n 3 --out smoke_longmem`으로 API 연결을 확인할 수 있다.
`--judge`를 빼면 EM/F1만 계산한다. 긴 서술형 정답이 있으므로 semantic correctness를 함께 보는 것을 권장한다.
judge는 동일한 gpt-6-luna로 reference와 candidate를 비교하는 **custom rubric**이며 공식 LongMemEval 평가 스크립트와 동일하지 않다.
judge 결과에도 오류가 있을 수 있어 실패 사례/경계 사례를 직접 확인해야 한다.
judge는 원문 질문/질문 시각/reference/candidate만 보며 답변 생성 단계와 분리한다.

## 답변 입력

| Variant | 질문 | 근거 | 논리적 파이프라인 호출 |
|---|---|---|---:|
| raw_all | 원문 | 전체 oracle 세션의 메시지 | 1 |
| raw_selected | 원문 | selector가 고른 메시지 | 2 |
| rewrite_only | rewrite | 없음 | 2 |
| rewrite_selected | rewrite | 선택 메시지 | 3 |
| raw_rewrite_selected | 원문 + rewrite | 선택 메시지 | 3 |
| rewrite_notes | rewrite | 질문 관련 사실·날짜·수정 내역 notes | 3 |

모든 방식에서 질문 시각을 유지한다. 이력이 있는 방식에서는 세션 시각도 유지한다.
예제당 rewrite/selection/notes 각각 한 번 생성해 공유한다.
selector는 원래 질문과 전체 oracle 이력을 사용하고 rewrite는 보지 않는다.
notes도 원문 질문 기준으로 생성한다. 최대 512단어는 프롬프트 지침이며 실제 단어 수를 하드 컷하지 않는다.
답변 프롬프트는 전 방식 동일하다.

실제 API 요청: 예제당 preprocessing 3회 + answer 6회 = **9회**.
100개 **900회**, --judge이면 추가 600회로 **1,500회** (재시도 제외).
logical calls/latency/tokens는 각 방식에 필요한 전처리 비용만 포함하며 judge 비용은 제외한다.
공유 캐시에 저장된 stage 관측 시간을 재사용하므로 논리적 latency와 전체 실행 wall time은 다르다.
API 오류/JSON validation 오류는 기록하며 동일 명령 재실행으로 성공한 stage를 재사용한다.
프롬프트/모델/표본/judge 설정을 바꾸면 새 --out이 필요하다.

## 결과

- `RESULTS.md`: 전체 및 유형별 EM/F1/semantic accuracy/지연 비교.
- `summary.json`: paired bootstrap CI, selector의 evidence recall/precision, 세션/메시지 수.
- `predictions.jsonl`: 답변, 공유 rewrite, notes, 선택 인덱스, 정답.
- `cache/`: API stage별 checkpoint.
- `samples.json`, `config.json`: 표본 및 실행 조건.

EM/F1은 영어 QA 정규화(max가 아닌 single reference) 기반 탐색 지표이며 공식 leaderboard 수치가 아니다.
선택 evidence precision은 has_answer turn만 positives로 보기 때문에 보조 문맥을 적절히 선택해도 낮아질 수 있다.
has_answer turn label이 없는 예제는 turn recall/precision을 null로 둔다.
전체 EM/F1에서 API 오류는 0점, semantic accuracy는 valid-only이며 errors와 valid_n을 함께 확인한다.
두 방식의 paired 비교는 해당 두 방식 모두 성공한 질문만 포함한다.

`rewrite_selected > rewrite_only`이면 명확한 질문만으로는 전달되지 않은 과거 사실이 도움이 된 것이다.
`rewrite_notes ≈ rewrite_selected`이면 전체 관련 메시지 대신 사실 notes로 압축하는 방향을 검토할 수 있다.
`raw_all > selected`이면 selector가 필요한 증거/수정 내역을 누락했는지 확인한다.
현재 패키지에는 실제 gpt-6-luna 실행 결과가 없다. 데이터 검증과 mock orchestration만 검증했다.

## Source / License

LongMemEval, ICLR 2025, Benchmarking Chat Assistants on Long-Term Interactive Memory.
Repository: https://github.com/xiaowu0162/LongMemEval
Paper: https://arxiv.org/abs/2410.10813
Dataset: https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned
공식 oracle: https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned/resolve/main/longmemeval_oracle.json
Dataset card license: MIT. SOURCE_LICENSE에 원본 repository 라이선스를 포함한다.

재생성:

```bash
python3 prepare.py --source longmemeval_oracle.json --out samples_100.json
```

source 파일이 없으면 공식 oracle JSON을 다운로드한다. main이 변경될 수 있으므로 현재 첨부 표본과 manifest로 결과를 재현한다.

## 실행 중 오류 확인

완료된 샘플은 즉시 predictions.jsonl에 저장됩니다. errors.jsonl에는 실패 행만 저장하며 콘솔 ERROR DETAIL에는 실패 단계와 예외 원인을 출력합니다. 기존 실행을 중지한 뒤 같은 명령으로 재실행하면 성공한 단계 캐시를 재사용합니다. 실행 시작 시 두 로그는 이번 실행 기준으로 다시 작성되며 cache는 보존됩니다.

## JSON 및 평가 출력 수정
Selection과 judge는 Responses API의 strict JSON schema를 사용합니다. Selection은 indices의 범위와 중복을 검증하며 잘못된 형식은 최대 3회 시도합니다. 재시도 비용을 합산합니다. 관련 전처리가 실패한 방식만 ERROR로 기록합니다. raw_all은 selection 없이 실행됩니다.
콘솔은 EM/F1/judge와 EM 불일치의 실제 gold/prediction을 출력합니다. EM은 정규화 후 완전 일치를 유지합니다. 자유 서술형 LongMemEval에서는 semantic judge와 F1도 함께 봐야 합니다.
프롬프트와 출력 형식이 변경되었으므로 --out results_longmem_v2로 실행하세요. 기존 결과는 보존하세요. Strict JSON schema를 지원하는 Responses API endpoint가 필요합니다.

## 최소 답변 프롬프트
답변은 문장·설명·Markdown을 생략하고 요청된 값만 출력합니다. 개수는 숫자, 금액은 통화 기호와 금액, 시간은 시각, 목록은 쉼표로 구분한 모든 항목을 반환합니다. EM/F1 계산은 유지합니다. 자유형 날짜와 목록은 형식 차이 때문에 EM이 낮을 수 있습니다.
LLM judge 없이 실행:
```bash
python3 bench.py --n 100 --model gpt-6-luna --effort none --concurrency 4 --out results_longmem_v3
```
답변 프롬프트가 변경되었으므로 새 결과 폴더를 사용합니다.
