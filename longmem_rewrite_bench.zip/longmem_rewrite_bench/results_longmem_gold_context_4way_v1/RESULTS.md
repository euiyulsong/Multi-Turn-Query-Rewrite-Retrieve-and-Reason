# LongMemEval rewrite vs memory

| Scope | Variant | EM | F1 | Semantic accuracy | Seconds | Errors |
|---|---|---:|---:|---:|---:|---:|
| all | raw_all | 0.410 | 0.554 | None | 1.6452919224499964 | 0 |
| all | single_raw | 0.430 | 0.549 | None | 1.7474516103198767 | 0 |
| all | rewrite_only | 0.390 | 0.549 | None | 3.134911341079842 | 0 |
| all | multiturn_rewrite | 0.430 | 0.583 | None | 3.067440859360013 | 0 |
| knowledge-update | raw_all | 0.576 | 0.709 | None | 1.431922729454417 | 0 |
| knowledge-update | single_raw | 0.576 | 0.709 | None | 1.9504879754848927 | 0 |
| knowledge-update | rewrite_only | 0.606 | 0.747 | None | 2.9242963510604376 | 0 |
| knowledge-update | multiturn_rewrite | 0.576 | 0.726 | None | 2.8447313282121094 | 0 |
| multi-session | raw_all | 0.471 | 0.548 | None | 1.705358533558865 | 0 |
| multi-session | single_raw | 0.500 | 0.562 | None | 1.6398900610292377 | 0 |
| multi-session | rewrite_only | 0.412 | 0.487 | None | 2.968201084411703 | 0 |
| multi-session | multiturn_rewrite | 0.500 | 0.556 | None | 3.0433779459120105 | 0 |
| temporal-reasoning | raw_all | 0.182 | 0.404 | None | 1.7967743040000752 | 0 |
| temporal-reasoning | single_raw | 0.212 | 0.376 | None | 1.6552362353330947 | 0 |
| temporal-reasoning | rewrite_only | 0.152 | 0.414 | None | 3.5172884137270253 | 0 |
| temporal-reasoning | multiturn_rewrite | 0.212 | 0.469 | None | 3.3149424831513126 | 0 |

This is a 100-question oracle-context ablation, not an official leaderboard evaluation.
Question-only rewrite discards factual memory; rewrite_notes explicitly retains factual evidence.
Judge evaluation cost is excluded from pipeline latency/tokens.
