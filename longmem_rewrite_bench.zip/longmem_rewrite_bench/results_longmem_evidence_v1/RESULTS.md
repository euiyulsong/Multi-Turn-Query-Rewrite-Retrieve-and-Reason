# LongMemEval rewrite vs memory

| Scope | Variant | EM | F1 | Semantic accuracy | Seconds | Errors |
|---|---|---:|---:|---:|---:|---:|
| all | raw_all | 0.380 | 0.515 | None | 1.3747556817299846 | 0 |
| all | raw_selected | 0.460 | 0.589 | None | 2.881744344160052 | 0 |
| all | rewrite_only | 0.520 | 0.649 | None | 3.481510867899906 | 0 |
| all | rewrite_selected | 0.520 | 0.658 | None | 5.130364993809817 | 0 |
| all | raw_rewrite_selected | 0.550 | 0.663 | None | 5.1103921007598725 | 0 |
| all | rewrite_notes | 0.450 | 0.594 | None | 5.922914768499876 | 6 |
| knowledge-update | raw_all | 0.545 | 0.698 | None | 1.4446790301211545 | 0 |
| knowledge-update | raw_selected | 0.636 | 0.729 | None | 2.9095368540907987 | 0 |
| knowledge-update | rewrite_only | 0.667 | 0.770 | None | 3.272191083363313 | 0 |
| knowledge-update | rewrite_selected | 0.667 | 0.766 | None | 5.00574938315119 | 0 |
| knowledge-update | raw_rewrite_selected | 0.697 | 0.758 | None | 5.001257846454267 | 0 |
| knowledge-update | rewrite_notes | 0.667 | 0.768 | None | 5.536780636580583 | 2 |
| multi-session | raw_all | 0.412 | 0.483 | None | 1.3501296039411874 | 0 |
| multi-session | raw_selected | 0.559 | 0.615 | None | 2.7777797079709083 | 0 |
| multi-session | rewrite_only | 0.588 | 0.644 | None | 3.3860015282646545 | 0 |
| multi-session | rewrite_selected | 0.618 | 0.673 | None | 4.917202769647006 | 0 |
| multi-session | raw_rewrite_selected | 0.647 | 0.703 | None | 4.909262224852843 | 0 |
| multi-session | rewrite_notes | 0.471 | 0.526 | None | 6.086867793031104 | 2 |
| temporal-reasoning | raw_all | 0.182 | 0.366 | None | 1.3302046559090905 | 0 |
| temporal-reasoning | raw_selected | 0.182 | 0.423 | None | 2.961066913939331 | 0 |
| temporal-reasoning | rewrite_only | 0.303 | 0.533 | None | 3.7892342144849396 | 0 |
| temporal-reasoning | rewrite_selected | 0.273 | 0.533 | None | 5.474602289969522 | 0 |
| temporal-reasoning | raw_rewrite_selected | 0.303 | 0.527 | None | 5.426751075696964 | 0 |
| temporal-reasoning | rewrite_notes | 0.212 | 0.489 | None | 6.139807068644997 | 2 |

This is a 100-question oracle-context ablation, not an official leaderboard evaluation.
Question-only rewrite discards factual memory; rewrite_notes explicitly retains factual evidence.
Judge evaluation cost is excluded from pipeline latency/tokens.
