# LongMemEval rewrite vs memory

| Scope | Variant | EM | F1 | Semantic accuracy | Seconds | Errors |
|---|---|---:|---:|---:|---:|---:|
| all | raw_all | 0.470 | 0.595 | None | 1.44819996291013 | 0 |
| all | single_raw | 0.460 | 0.602 | None | 1.3512758729699634 | 0 |
| all | rewrite_only | 0.490 | 0.622 | None | 2.9131799911397684 | 0 |
| knowledge-update | raw_all | 0.636 | 0.748 | None | 1.426521847575824 | 0 |
| knowledge-update | single_raw | 0.576 | 0.728 | None | 1.3119341929696295 | 0 |
| knowledge-update | rewrite_only | 0.667 | 0.763 | None | 2.883966499969657 | 0 |
| multi-session | raw_all | 0.529 | 0.606 | None | 1.4943156703529894 | 0 |
| multi-session | single_raw | 0.529 | 0.602 | None | 1.357942983529403 | 0 |
| multi-session | rewrite_only | 0.588 | 0.664 | None | 2.935399333999746 | 0 |
| temporal-reasoning | raw_all | 0.242 | 0.431 | None | 1.4223649251214903 | 0 |
| temporal-reasoning | single_raw | 0.273 | 0.476 | None | 1.3837484087575418 | 0 |
| temporal-reasoning | rewrite_only | 0.212 | 0.439 | None | 2.919500826029903 | 0 |

This is a 100-question oracle-context ablation, not an official leaderboard evaluation.
Question-only rewrite discards factual memory; rewrite_notes explicitly retains factual evidence.
Judge evaluation cost is excluded from pipeline latency/tokens.
