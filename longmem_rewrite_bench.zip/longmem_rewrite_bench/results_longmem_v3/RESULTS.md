# LongMemEval rewrite vs memory

| Scope | Variant | EM | F1 | Semantic accuracy | Seconds | Errors |
|---|---|---:|---:|---:|---:|---:|
| all | raw_all | 0.420 | 0.559 | None | 1.4981637641799626 | 0 |
| all | raw_selected | 0.460 | 0.590 | None | 3.3773794323000494 | 0 |
| all | rewrite_only | 0.050 | 0.083 | None | 3.0552950179500296 | 0 |
| all | rewrite_selected | 0.460 | 0.609 | None | 5.019882831780015 | 0 |
| all | raw_rewrite_selected | 0.490 | 0.627 | None | 5.001766585020023 | 0 |
| all | rewrite_notes | 0.460 | 0.587 | None | 6.029870717697965 | 4 |
| knowledge-update | raw_all | 0.606 | 0.722 | None | 1.4906052081818362 | 0 |
| knowledge-update | raw_selected | 0.636 | 0.721 | None | 3.315038345454537 | 0 |
| knowledge-update | rewrite_only | 0.000 | 0.021 | None | 3.032913395697092 | 0 |
| knowledge-update | rewrite_selected | 0.576 | 0.709 | None | 4.981294545060639 | 0 |
| knowledge-update | raw_rewrite_selected | 0.636 | 0.743 | None | 4.927384176545357 | 0 |
| knowledge-update | rewrite_notes | 0.727 | 0.790 | None | 5.911151659181969 | 0 |
| multi-session | raw_all | 0.441 | 0.523 | None | 1.3945700855587186 | 0 |
| multi-session | raw_selected | 0.559 | 0.612 | None | 3.5000366474707656 | 0 |
| multi-session | rewrite_only | 0.059 | 0.059 | None | 2.9449695594999223 | 0 |
| multi-session | rewrite_selected | 0.559 | 0.615 | None | 4.986381460882325 | 0 |
| multi-session | raw_rewrite_selected | 0.618 | 0.673 | None | 4.981251469176561 | 0 |
| multi-session | rewrite_notes | 0.471 | 0.546 | None | 5.995305983939391 | 1 |
| temporal-reasoning | raw_all | 0.212 | 0.433 | None | 1.6124552011817948 | 0 |
| temporal-reasoning | raw_selected | 0.182 | 0.435 | None | 3.313346418666642 | 0 |
| temporal-reasoning | rewrite_only | 0.091 | 0.171 | None | 3.191345294363683 | 0 |
| temporal-reasoning | rewrite_selected | 0.242 | 0.504 | None | 5.092987682454584 | 0 |
| temporal-reasoning | raw_rewrite_selected | 0.212 | 0.464 | None | 5.097285779515225 | 0 |
| temporal-reasoning | rewrite_notes | 0.182 | 0.427 | None | 6.198482889199992 | 3 |

This is a 100-question oracle-context ablation, not an official leaderboard evaluation.
Question-only rewrite discards factual memory; rewrite_notes explicitly retains factual evidence.
Judge evaluation cost is excluded from pipeline latency/tokens.
